#include<iostream>
using namespace std;
int main(){
int a=4;
for(int i = 0; i< a;i++){
for(int j=0;j<=i;j++){
cout<< "*";
}
cout<<endl;
}
return 0;
}


